package com.winterchen.config.dbconfig;

/**
 * 作者：齐文杰
 * 时间：2018/7/29
 */
public @interface SchoolDataSource {
}

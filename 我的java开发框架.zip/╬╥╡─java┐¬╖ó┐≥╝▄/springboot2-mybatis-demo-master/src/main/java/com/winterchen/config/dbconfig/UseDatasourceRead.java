package com.winterchen.config.dbconfig;
public @interface UseDatasourceRead {
}

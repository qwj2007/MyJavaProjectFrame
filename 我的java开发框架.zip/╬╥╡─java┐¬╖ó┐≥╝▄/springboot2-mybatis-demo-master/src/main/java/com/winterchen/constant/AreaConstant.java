package com.winterchen.constant;

/**
 * Created by hanjd on 2017/3/7.
 */
public class AreaConstant {
    public static final String AREA_COOKIE_KEY = "xyautoarea";
}

package com.winterchen.config.dbconfig;

public @interface WorldDatasource {
}
